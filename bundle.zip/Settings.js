/*! For license information please see Settings.js.LICENSE.txt */
define('Settings', ['react', '@lumx/react', 'lumapps-sdk-js', 'axios'], function (
    __WEBPACK_EXTERNAL_MODULE__650__,
    __WEBPACK_EXTERNAL_MODULE__432__,
    __WEBPACK_EXTERNAL_MODULE__224__,
    __WEBPACK_EXTERNAL_MODULE__873__,
) {
    return (function () {
        function __webpack_require__(moduleId) {
            var cachedModule = __webpack_module_cache__[moduleId];
            if (void 0 !== cachedModule) return cachedModule.exports;
            var module = (__webpack_module_cache__[moduleId] = { id: moduleId, exports: {} });
            return __webpack_modules__[moduleId](module, module.exports, __webpack_require__), module.exports;
        }
        var deferred,
            __webpack_modules__ = {
                839: function (module) {
                    'use strict';
                    module.exports = function (cssWithMappingToString) {
                        var list = [];
                        return (
                            (list.toString = function () {
                                return this.map(function (item) {
                                    var content = '',
                                        needLayer = void 0 !== item[5];
                                    return (
                                        item[4] && (content += '@supports ('.concat(item[4], ') {')),
                                        item[2] && (content += '@media '.concat(item[2], ' {')),
                                        needLayer &&
                                            (content += '@layer'.concat(
                                                item[5].length > 0 ? ' '.concat(item[5]) : '',
                                                ' {',
                                            )),
                                        (content += cssWithMappingToString(item)),
                                        needLayer && (content += '}'),
                                        item[2] && (content += '}'),
                                        item[4] && (content += '}'),
                                        content
                                    );
                                }).join('');
                            }),
                            (list.i = function (modules, media, dedupe, supports, layer) {
                                'string' == typeof modules && (modules = [[null, modules, void 0]]);
                                var alreadyImportedModules = {};
                                if (dedupe)
                                    for (var k = 0; k < this.length; k++) {
                                        var id = this[k][0];
                                        null != id && (alreadyImportedModules[id] = !0);
                                    }
                                for (var _k = 0; _k < modules.length; _k++) {
                                    var item = [].concat(modules[_k]);
                                    (dedupe && alreadyImportedModules[item[0]]) ||
                                        (void 0 !== layer &&
                                            (void 0 === item[5] ||
                                                (item[1] = '@layer'
                                                    .concat(item[5].length > 0 ? ' '.concat(item[5]) : '', ' {')
                                                    .concat(item[1], '}')),
                                            (item[5] = layer)),
                                        media &&
                                            (item[2]
                                                ? ((item[1] = '@media '.concat(item[2], ' {').concat(item[1], '}')),
                                                  (item[2] = media))
                                                : (item[2] = media)),
                                        supports &&
                                            (item[4]
                                                ? ((item[1] = '@supports ('
                                                      .concat(item[4], ') {')
                                                      .concat(item[1], '}')),
                                                  (item[4] = supports))
                                                : (item[4] = ''.concat(supports))),
                                        list.push(item));
                                }
                            }),
                            list
                        );
                    };
                },
                682: function (module) {
                    'use strict';
                    module.exports = function (i) {
                        return i[1];
                    };
                },
                891: function (module) {
                    function monadic(fn, cache, serializer, arg) {
                        var value,
                            cacheKey =
                                ((value = arg),
                                null == value || 'number' == typeof value || 'boolean' == typeof value
                                    ? arg
                                    : serializer(arg)),
                            computedValue = cache.get(cacheKey);
                        return (
                            void 0 === computedValue &&
                                ((computedValue = fn.call(this, arg)), cache.set(cacheKey, computedValue)),
                            computedValue
                        );
                    }
                    function variadic(fn, cache, serializer) {
                        var args = Array.prototype.slice.call(arguments, 3),
                            cacheKey = serializer(args),
                            computedValue = cache.get(cacheKey);
                        return (
                            void 0 === computedValue &&
                                ((computedValue = fn.apply(this, args)), cache.set(cacheKey, computedValue)),
                            computedValue
                        );
                    }
                    function assemble(fn, context, strategy, cache, serialize) {
                        return strategy.bind(context, fn, cache, serialize);
                    }
                    function strategyDefault(fn, options) {
                        var strategy = 1 === fn.length ? monadic : variadic;
                        return assemble(fn, this, strategy, options.cache.create(), options.serializer);
                    }
                    function serializerDefault() {
                        return JSON.stringify(arguments);
                    }
                    function ObjectWithoutPrototypeCache() {
                        this.cache = Object.create(null);
                    }
                    (ObjectWithoutPrototypeCache.prototype.has = function (key) {
                        return key in this.cache;
                    }),
                        (ObjectWithoutPrototypeCache.prototype.get = function (key) {
                            return this.cache[key];
                        }),
                        (ObjectWithoutPrototypeCache.prototype.set = function (key, value) {
                            this.cache[key] = value;
                        });
                    var cacheDefault = {
                        create: function () {
                            return new ObjectWithoutPrototypeCache();
                        },
                    };
                    (module.exports = function (fn, options) {
                        var cache = options && options.cache ? options.cache : cacheDefault,
                            serializer = options && options.serializer ? options.serializer : serializerDefault,
                            strategy = options && options.strategy ? options.strategy : strategyDefault;
                        return strategy(fn, { cache: cache, serializer: serializer });
                    }),
                        (module.exports.strategies = {
                            variadic: function (fn, options) {
                                var strategy = variadic;
                                return assemble(fn, this, strategy, options.cache.create(), options.serializer);
                            },
                            monadic: function (fn, options) {
                                var strategy = monadic;
                                return assemble(fn, this, strategy, options.cache.create(), options.serializer);
                            },
                        });
                },
                289: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    'use strict';
                    function createFastMemoizeCache(store) {
                        return {
                            create: function () {
                                return {
                                    has: function (key) {
                                        return key in store;
                                    },
                                    get: function (key) {
                                        return store[key];
                                    },
                                    set: function (key, value) {
                                        store[key] = value;
                                    },
                                };
                            },
                        };
                    }
                    __webpack_require__.d(__webpack_exports__, {
                        a: function () {
                            return IntlMessageFormat;
                        },
                    });
                    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(763),
                        _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(356),
                        fast_memoize__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(891),
                        fast_memoize__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(
                            fast_memoize__WEBPACK_IMPORTED_MODULE_1__,
                        ),
                        _formatters__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(115),
                        _memoizeIntl =
                            fast_memoize__WEBPACK_IMPORTED_MODULE_1___default() ||
                            fast_memoize__WEBPACK_IMPORTED_MODULE_1__,
                        memoizeIntl = _memoizeIntl,
                        IntlMessageFormat = (function () {
                            function IntlMessageFormat(message, locales, overrideFormats, opts) {
                                var defaultConfig,
                                    configs,
                                    cache,
                                    _this = this;
                                if (
                                    (void 0 === locales && (locales = IntlMessageFormat.defaultLocale),
                                    (this.formatterCache = { number: {}, dateTime: {}, pluralRules: {} }),
                                    (this.format = function (values) {
                                        var parts = _this.formatToParts(values);
                                        if (1 === parts.length) return parts[0].value;
                                        var result = parts.reduce(function (all, part) {
                                            return (
                                                all.length &&
                                                part.type === _formatters__WEBPACK_IMPORTED_MODULE_2__.a.literal &&
                                                'string' == typeof all[all.length - 1]
                                                    ? (all[all.length - 1] += part.value)
                                                    : all.push(part.value),
                                                all
                                            );
                                        }, []);
                                        return result.length <= 1 ? result[0] || '' : result;
                                    }),
                                    (this.formatToParts = function (values) {
                                        return (0, _formatters__WEBPACK_IMPORTED_MODULE_2__.b)(
                                            _this.ast,
                                            _this.locales,
                                            _this.formatters,
                                            _this.formats,
                                            values,
                                            void 0,
                                            _this.message,
                                        );
                                    }),
                                    (this.resolvedOptions = function () {
                                        return { locale: Intl.NumberFormat.supportedLocalesOf(_this.locales)[0] };
                                    }),
                                    (this.getAst = function () {
                                        return _this.ast;
                                    }),
                                    'string' == typeof message)
                                ) {
                                    if (((this.message = message), !IntlMessageFormat.__parse))
                                        throw new TypeError(
                                            'IntlMessageFormat.__parse must be set to process `message` of type `string`',
                                        );
                                    this.ast = IntlMessageFormat.__parse(message, {
                                        ignoreTag: null == opts ? void 0 : opts.ignoreTag,
                                    });
                                } else this.ast = message;
                                if (!Array.isArray(this.ast))
                                    throw new TypeError('A message must be provided as a String or AST.');
                                (this.formats =
                                    ((defaultConfig = IntlMessageFormat.formats),
                                    (configs = overrideFormats),
                                    configs
                                        ? Object.keys(defaultConfig).reduce(function (all, k) {
                                              var c1, c2;
                                              return (
                                                  (all[k] =
                                                      ((c1 = defaultConfig[k]),
                                                      (c2 = configs[k]),
                                                      c2
                                                          ? (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)(
                                                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)(
                                                                    (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)(
                                                                        {},
                                                                        c1 || {},
                                                                    ),
                                                                    c2 || {},
                                                                ),
                                                                Object.keys(c1).reduce(function (all, k) {
                                                                    return (
                                                                        (all[k] = (0,
                                                                        tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)(
                                                                            (0,
                                                                            tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)(
                                                                                {},
                                                                                c1[k],
                                                                            ),
                                                                            c2[k] || {},
                                                                        )),
                                                                        all
                                                                    );
                                                                }, {}),
                                                            )
                                                          : c1)),
                                                  all
                                              );
                                          }, (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, defaultConfig))
                                        : defaultConfig)),
                                    (this.locales = locales),
                                    (this.formatters =
                                        (opts && opts.formatters) ||
                                        ((cache = this.formatterCache),
                                        void 0 === cache && (cache = { number: {}, dateTime: {}, pluralRules: {} }),
                                        {
                                            getNumberFormat: memoizeIntl(
                                                function () {
                                                    for (var _a, args = [], _i = 0; _i < arguments.length; _i++)
                                                        args[_i] = arguments[_i];
                                                    return new ((_a = Intl.NumberFormat).bind.apply(
                                                        _a,
                                                        (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)(
                                                            [void 0],
                                                            args,
                                                        ),
                                                    ))();
                                                },
                                                {
                                                    cache: createFastMemoizeCache(cache.number),
                                                    strategy: memoizeIntl.strategies.variadic,
                                                },
                                            ),
                                            getDateTimeFormat: memoizeIntl(
                                                function () {
                                                    for (var _a, args = [], _i = 0; _i < arguments.length; _i++)
                                                        args[_i] = arguments[_i];
                                                    return new ((_a = Intl.DateTimeFormat).bind.apply(
                                                        _a,
                                                        (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)(
                                                            [void 0],
                                                            args,
                                                        ),
                                                    ))();
                                                },
                                                {
                                                    cache: createFastMemoizeCache(cache.dateTime),
                                                    strategy: memoizeIntl.strategies.variadic,
                                                },
                                            ),
                                            getPluralRules: memoizeIntl(
                                                function () {
                                                    for (var _a, args = [], _i = 0; _i < arguments.length; _i++)
                                                        args[_i] = arguments[_i];
                                                    return new ((_a = Intl.PluralRules).bind.apply(
                                                        _a,
                                                        (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)(
                                                            [void 0],
                                                            args,
                                                        ),
                                                    ))();
                                                },
                                                {
                                                    cache: createFastMemoizeCache(cache.pluralRules),
                                                    strategy: memoizeIntl.strategies.variadic,
                                                },
                                            ),
                                        }));
                            }
                            return (
                                Object.defineProperty(IntlMessageFormat, 'defaultLocale', {
                                    get: function () {
                                        return (
                                            IntlMessageFormat.memoizedDefaultLocale ||
                                                (IntlMessageFormat.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale),
                                            IntlMessageFormat.memoizedDefaultLocale
                                        );
                                    },
                                    enumerable: !1,
                                    configurable: !0,
                                }),
                                (IntlMessageFormat.memoizedDefaultLocale = null),
                                (IntlMessageFormat.__parse =
                                    _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_3__.parse),
                                (IntlMessageFormat.formats = {
                                    number: { currency: { style: 'currency' }, percent: { style: 'percent' } },
                                    date: {
                                        short: { month: 'numeric', day: 'numeric', year: '2-digit' },
                                        medium: { month: 'short', day: 'numeric', year: 'numeric' },
                                        long: { month: 'long', day: 'numeric', year: 'numeric' },
                                        full: { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' },
                                    },
                                    time: {
                                        short: { hour: 'numeric', minute: 'numeric' },
                                        medium: { hour: 'numeric', minute: 'numeric', second: 'numeric' },
                                        long: {
                                            hour: 'numeric',
                                            minute: 'numeric',
                                            second: 'numeric',
                                            timeZoneName: 'short',
                                        },
                                        full: {
                                            hour: 'numeric',
                                            minute: 'numeric',
                                            second: 'numeric',
                                            timeZoneName: 'short',
                                        },
                                    },
                                }),
                                IntlMessageFormat
                            );
                        })();
                },
                49: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    'use strict';
                    __webpack_require__.d(__webpack_exports__, {
                        a: function () {
                            return ErrorCode;
                        },
                        b: function () {
                            return FormatError;
                        },
                        c: function () {
                            return InvalidValueError;
                        },
                        d: function () {
                            return InvalidValueTypeError;
                        },
                        e: function () {
                            return MissingValueError;
                        },
                    });
                    var ErrorCode,
                        tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(763);
                    !(function (ErrorCode) {
                        (ErrorCode.MISSING_VALUE = 'MISSING_VALUE'),
                            (ErrorCode.INVALID_VALUE = 'INVALID_VALUE'),
                            (ErrorCode.MISSING_INTL_API = 'MISSING_INTL_API');
                    })(ErrorCode || (ErrorCode = {}));
                    var FormatError = (function (_super) {
                            function FormatError(msg, code, originalMessage) {
                                var _this = _super.call(this, msg) || this;
                                return (_this.code = code), (_this.originalMessage = originalMessage), _this;
                            }
                            return (
                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(FormatError, _super),
                                (FormatError.prototype.toString = function () {
                                    return '[formatjs Error: ' + this.code + '] ' + this.message;
                                }),
                                FormatError
                            );
                        })(Error),
                        InvalidValueError = (function (_super) {
                            function InvalidValueError(variableId, value, options, originalMessage) {
                                return (
                                    _super.call(
                                        this,
                                        'Invalid values for "' +
                                            variableId +
                                            '": "' +
                                            value +
                                            '". Options are "' +
                                            Object.keys(options).join('", "') +
                                            '"',
                                        ErrorCode.INVALID_VALUE,
                                        originalMessage,
                                    ) || this
                                );
                            }
                            return (
                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(InvalidValueError, _super),
                                InvalidValueError
                            );
                        })(FormatError),
                        InvalidValueTypeError = (function (_super) {
                            function InvalidValueTypeError(value, type, originalMessage) {
                                return (
                                    _super.call(
                                        this,
                                        'Value for "' + value + '" must be of type ' + type,
                                        ErrorCode.INVALID_VALUE,
                                        originalMessage,
                                    ) || this
                                );
                            }
                            return (
                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(InvalidValueTypeError, _super),
                                InvalidValueTypeError
                            );
                        })(FormatError),
                        MissingValueError = (function (_super) {
                            function MissingValueError(variableId, originalMessage) {
                                return (
                                    _super.call(
                                        this,
                                        'The intl string context variable "' +
                                            variableId +
                                            '" was not provided to the string "' +
                                            originalMessage +
                                            '"',
                                        ErrorCode.MISSING_VALUE,
                                        originalMessage,
                                    ) || this
                                );
                            }
                            return (
                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(MissingValueError, _super),
                                MissingValueError
                            );
                        })(FormatError);
                },
                115: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    'use strict';
                    function mergeLiteral(parts) {
                        return parts.length < 2
                            ? parts
                            : parts.reduce(function (all, part) {
                                  var lastPart = all[all.length - 1];
                                  return (
                                      lastPart && lastPart.type === PART_TYPE.literal && part.type === PART_TYPE.literal
                                          ? (lastPart.value += part.value)
                                          : all.push(part),
                                      all
                                  );
                              }, []);
                    }
                    function isFormatXMLElementFn(el) {
                        return 'function' == typeof el;
                    }
                    function formatToParts(
                        els,
                        locales,
                        formatters,
                        formats,
                        values,
                        currentPluralValue,
                        originalMessage,
                    ) {
                        if (
                            1 === els.length &&
                            (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isLiteralElement)(
                                els[0],
                            )
                        )
                            return [{ type: PART_TYPE.literal, value: els[0].value }];
                        for (var result = [], _i = 0, els_1 = els; _i < els_1.length; _i++) {
                            var el = els_1[_i];
                            if (
                                (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isLiteralElement)(
                                    el,
                                )
                            )
                                result.push({ type: PART_TYPE.literal, value: el.value });
                            else if (
                                (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isPoundElement)(el)
                            )
                                'number' == typeof currentPluralValue &&
                                    result.push({
                                        type: PART_TYPE.literal,
                                        value: formatters.getNumberFormat(locales).format(currentPluralValue),
                                    });
                            else {
                                var varName = el.value;
                                if (!values || !(varName in values))
                                    throw new _error__WEBPACK_IMPORTED_MODULE_1__.e(varName, originalMessage);
                                var value = values[varName];
                                if (
                                    (0,
                                    _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isArgumentElement)(
                                        el,
                                    )
                                )
                                    (value && 'string' != typeof value && 'number' != typeof value) ||
                                        (value =
                                            'string' == typeof value || 'number' == typeof value ? String(value) : ''),
                                        result.push({
                                            type: 'string' == typeof value ? PART_TYPE.literal : PART_TYPE.object,
                                            value: value,
                                        });
                                else if (
                                    (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isDateElement)(
                                        el,
                                    )
                                ) {
                                    var style =
                                        'string' == typeof el.style
                                            ? formats.date[el.style]
                                            : (0,
                                              _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isDateTimeSkeleton)(
                                                  el.style,
                                              )
                                            ? el.style.parsedOptions
                                            : void 0;
                                    result.push({
                                        type: PART_TYPE.literal,
                                        value: formatters.getDateTimeFormat(locales, style).format(value),
                                    });
                                } else if (
                                    (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isTimeElement)(
                                        el,
                                    )
                                ) {
                                    style =
                                        'string' == typeof el.style
                                            ? formats.time[el.style]
                                            : (0,
                                              _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isDateTimeSkeleton)(
                                                  el.style,
                                              )
                                            ? el.style.parsedOptions
                                            : void 0;
                                    result.push({
                                        type: PART_TYPE.literal,
                                        value: formatters.getDateTimeFormat(locales, style).format(value),
                                    });
                                } else if (
                                    (0,
                                    _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isNumberElement)(el)
                                ) {
                                    style =
                                        'string' == typeof el.style
                                            ? formats.number[el.style]
                                            : (0,
                                              _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isNumberSkeleton)(
                                                  el.style,
                                              )
                                            ? el.style.parsedOptions
                                            : void 0;
                                    style && style.scale && (value *= style.scale || 1),
                                        result.push({
                                            type: PART_TYPE.literal,
                                            value: formatters.getNumberFormat(locales, style).format(value),
                                        });
                                } else {
                                    if (
                                        (0,
                                        _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isTagElement)(
                                            el,
                                        )
                                    ) {
                                        var children = el.children,
                                            value_1 = el.value,
                                            formatFn = values[value_1];
                                        if (!isFormatXMLElementFn(formatFn))
                                            throw new _error__WEBPACK_IMPORTED_MODULE_1__.d(
                                                value_1,
                                                'function',
                                                originalMessage,
                                            );
                                        var parts = formatToParts(
                                                children,
                                                locales,
                                                formatters,
                                                formats,
                                                values,
                                                currentPluralValue,
                                            ),
                                            chunks = formatFn(
                                                parts.map(function (p) {
                                                    return p.value;
                                                }),
                                            );
                                        Array.isArray(chunks) || (chunks = [chunks]),
                                            result.push.apply(
                                                result,
                                                chunks.map(function (c) {
                                                    return {
                                                        type:
                                                            'string' == typeof c ? PART_TYPE.literal : PART_TYPE.object,
                                                        value: c,
                                                    };
                                                }),
                                            );
                                    }
                                    if (
                                        (0,
                                        _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isSelectElement)(
                                            el,
                                        )
                                    ) {
                                        var opt = el.options[value] || el.options.other;
                                        if (!opt)
                                            throw new _error__WEBPACK_IMPORTED_MODULE_1__.c(
                                                el.value,
                                                value,
                                                Object.keys(el.options),
                                                originalMessage,
                                            );
                                        result.push.apply(
                                            result,
                                            formatToParts(opt.value, locales, formatters, formats, values),
                                        );
                                    } else if (
                                        (0,
                                        _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.isPluralElement)(
                                            el,
                                        )
                                    ) {
                                        opt = el.options['=' + value];
                                        if (!opt) {
                                            if (!Intl.PluralRules)
                                                throw new _error__WEBPACK_IMPORTED_MODULE_1__.b(
                                                    'Intl.PluralRules is not available in this environment.\nTry polyfilling it using "@formatjs/intl-pluralrules"\n',
                                                    _error__WEBPACK_IMPORTED_MODULE_1__.a.MISSING_INTL_API,
                                                    originalMessage,
                                                );
                                            var rule = formatters
                                                .getPluralRules(locales, { type: el.pluralType })
                                                .select(value - (el.offset || 0));
                                            opt = el.options[rule] || el.options.other;
                                        }
                                        if (!opt)
                                            throw new _error__WEBPACK_IMPORTED_MODULE_1__.c(
                                                el.value,
                                                value,
                                                Object.keys(el.options),
                                                originalMessage,
                                            );
                                        result.push.apply(
                                            result,
                                            formatToParts(
                                                opt.value,
                                                locales,
                                                formatters,
                                                formats,
                                                values,
                                                value - (el.offset || 0),
                                            ),
                                        );
                                    } else;
                                }
                            }
                        }
                        return mergeLiteral(result);
                    }
                    __webpack_require__.d(__webpack_exports__, {
                        a: function () {
                            return PART_TYPE;
                        },
                        b: function () {
                            return formatToParts;
                        },
                        c: function () {
                            return isFormatXMLElementFn;
                        },
                    });
                    var PART_TYPE,
                        _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(356),
                        _error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49);
                    !(function (PART_TYPE) {
                        (PART_TYPE[(PART_TYPE.literal = 0)] = 'literal'),
                            (PART_TYPE[(PART_TYPE.object = 1)] = 'object');
                    })(PART_TYPE || (PART_TYPE = {}));
                },
                763: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    'use strict';
                    function _typeof(obj) {
                        return (
                            (_typeof =
                                'function' == typeof Symbol && 'symbol' == typeof Symbol.iterator
                                    ? function (obj) {
                                          return typeof obj;
                                      }
                                    : function (obj) {
                                          return obj &&
                                              'function' == typeof Symbol &&
                                              obj.constructor === Symbol &&
                                              obj !== Symbol.prototype
                                              ? 'symbol'
                                              : typeof obj;
                                      }),
                            _typeof(obj)
                        );
                    }
                    function __extends(d, b) {
                        function __() {
                            this.constructor = d;
                        }
                        if ('function' != typeof b && null !== b)
                            throw new TypeError('Class extends value ' + String(b) + ' is not a constructor or null');
                        _extendStatics(d, b),
                            (d.prototype = null === b ? Object.create(b) : ((__.prototype = b.prototype), new __()));
                    }
                    function __rest(s, e) {
                        var t = {};
                        for (var p in s)
                            Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0 && (t[p] = s[p]);
                        if (null != s && 'function' == typeof Object.getOwnPropertySymbols) {
                            var i = 0;
                            for (p = Object.getOwnPropertySymbols(s); i < p.length; i++)
                                e.indexOf(p[i]) < 0 &&
                                    Object.prototype.propertyIsEnumerable.call(s, p[i]) &&
                                    (t[p[i]] = s[p[i]]);
                        }
                        return t;
                    }
                    function __decorate(decorators, target, key, desc) {
                        var d,
                            c = arguments.length,
                            r =
                                c < 3
                                    ? target
                                    : null === desc
                                    ? (desc = Object.getOwnPropertyDescriptor(target, key))
                                    : desc;
                        if (
                            'object' === ('undefined' == typeof Reflect ? 'undefined' : _typeof(Reflect)) &&
                            'function' == typeof Reflect.decorate
                        )
                            r = Reflect.decorate(decorators, target, key, desc);
                        else
                            for (var i = decorators.length - 1; i >= 0; i--)
                                (d = decorators[i]) &&
                                    (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
                        return c > 3 && r && Object.defineProperty(target, key, r), r;
                    }
                    function __param(paramIndex, decorator) {
                        return function (target, key) {
                            decorator(target, key, paramIndex);
                        };
                    }
                    function __metadata(metadataKey, metadataValue) {
                        if (
                            'object' === ('undefined' == typeof Reflect ? 'undefined' : _typeof(Reflect)) &&
                            'function' == typeof Reflect.metadata
                        )
                            return Reflect.metadata(metadataKey, metadataValue);
                    }
                    function __awaiter(thisArg, _arguments, P, generator) {
                        return new (P || (P = Promise))(function (resolve, reject) {
                            function fulfilled(value) {
                                try {
                                    step(generator.next(value));
                                } catch (e) {
                                    reject(e);
                                }
                            }
                            function rejected(value) {
                                try {
                                    step(generator.throw(value));
                                } catch (e) {
                                    reject(e);
                                }
                            }
                            function step(result) {
                                var value;
                                result.done
                                    ? resolve(result.value)
                                    : ((value = result.value),
                                      value instanceof P
                                          ? value
                                          : new P(function (resolve) {
                                                resolve(value);
                                            })).then(fulfilled, rejected);
                            }
                            step((generator = generator.apply(thisArg, _arguments || [])).next());
                        });
                    }
                    function __generator(thisArg, body) {
                        function verb(n) {
                            return function (v) {
                                return step([n, v]);
                            };
                        }
                        function step(op) {
                            if (f) throw new TypeError('Generator is already executing.');
                            for (; _; )
                                try {
                                    if (
                                        ((f = 1),
                                        y &&
                                            (t =
                                                2 & op[0]
                                                    ? y.return
                                                    : op[0]
                                                    ? y.throw || ((t = y.return) && t.call(y), 0)
                                                    : y.next) &&
                                            !(t = t.call(y, op[1])).done)
                                    )
                                        return t;
                                    switch (((y = 0), t && (op = [2 & op[0], t.value]), op[0])) {
                                        case 0:
                                        case 1:
                                            t = op;
                                            break;
                                        case 4:
                                            return _.label++, { value: op[1], done: !1 };
                                        case 5:
                                            _.label++, (y = op[1]), (op = [0]);
                                            continue;
                                        case 7:
                                            (op = _.ops.pop()), _.trys.pop();
                                            continue;
                                        default:
                                            if (
                                                !((t = _.trys),
                                                (t = t.length > 0 && t[t.length - 1]) || (6 !== op[0] && 2 !== op[0]))
                                            ) {
                                                _ = 0;
                                                continue;
                                            }
                                            if (3 === op[0] && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                                _.label = op[1];
                                                break;
                                            }
                                            if (6 === op[0] && _.label < t[1]) {
                                                (_.label = t[1]), (t = op);
                                                break;
                                            }
                                            if (t && _.label < t[2]) {
                                                (_.label = t[2]), _.ops.push(op);
                                                break;
                                            }
                                            t[2] && _.ops.pop(), _.trys.pop();
                                            continue;
                                    }
                                    op = body.call(thisArg, _);
                                } catch (e) {
                                    (op = [6, e]), (y = 0);
                                } finally {
                                    f = t = 0;
                                }
                            if (5 & op[0]) throw op[1];
                            return { value: op[0] ? op[1] : void 0, done: !0 };
                        }
                        var f,
                            y,
                            t,
                            g,
                            _ = {
                                label: 0,
                                sent: function () {
                                    if (1 & t[0]) throw t[1];
                                    return t[1];
                                },
                                trys: [],
                                ops: [],
                            };
                        return (
                            (g = { next: verb(0), throw: verb(1), return: verb(2) }),
                            'function' == typeof Symbol &&
                                (g[Symbol.iterator] = function () {
                                    return this;
                                }),
                            g
                        );
                    }
                    function __exportStar(m, o) {
                        for (var p in m)
                            'default' === p || Object.prototype.hasOwnProperty.call(o, p) || __createBinding(o, m, p);
                    }
                    function __values(o) {
                        var s = 'function' == typeof Symbol && Symbol.iterator,
                            m = s && o[s],
                            i = 0;
                        if (m) return m.call(o);
                        if (o && 'number' == typeof o.length)
                            return {
                                next: function () {
                                    return o && i >= o.length && (o = void 0), { value: o && o[i++], done: !o };
                                },
                            };
                        throw new TypeError(s ? 'Object is not iterable.' : 'Symbol.iterator is not defined.');
                    }
                    function __read(o, n) {
                        var m = 'function' == typeof Symbol && o[Symbol.iterator];
                        if (!m) return o;
                        var r,
                            e,
                            i = m.call(o),
                            ar = [];
                        try {
                            for (; (void 0 === n || n-- > 0) && !(r = i.next()).done; ) ar.push(r.value);
                        } catch (error) {
                            e = { error: error };
                        } finally {
                            try {
                                r && !r.done && (m = i.return) && m.call(i);
                            } finally {
                                if (e) throw e.error;
                            }
                        }
                        return ar;
                    }
                    function __spread() {
                        for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
                        return ar;
                    }
                    function __spreadArrays() {
                        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
                        var r = Array(s),
                            k = 0;
                        for (i = 0; i < il; i++)
                            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) r[k] = a[j];
                        return r;
                    }
                    function __spreadArray(to, from, pack) {
                        if (pack || 2 === arguments.length)
                            for (var ar, i = 0, l = from.length; i < l; i++)
                                (!ar && i in from) ||
                                    (ar || (ar = Array.prototype.slice.call(from, 0, i)), (ar[i] = from[i]));
                        return to.concat(ar || Array.prototype.slice.call(from));
                    }
                    function __await(v) {
                        return this instanceof __await ? ((this.v = v), this) : new __await(v);
                    }
                    function __asyncGenerator(thisArg, _arguments, generator) {
                        function verb(n) {
                            g[n] &&
                                (i[n] = function (v) {
                                    return new Promise(function (a, b) {
                                        q.push([n, v, a, b]) > 1 || resume(n, v);
                                    });
                                });
                        }
                        function resume(n, v) {
                            try {
                                (r = g[n](v)),
                                    r.value instanceof __await
                                        ? Promise.resolve(r.value.v).then(fulfill, reject)
                                        : settle(q[0][2], r);
                            } catch (e) {
                                settle(q[0][3], e);
                            }
                            var r;
                        }
                        function fulfill(value) {
                            resume('next', value);
                        }
                        function reject(value) {
                            resume('throw', value);
                        }
                        function settle(f, v) {
                            f(v), q.shift(), q.length && resume(q[0][0], q[0][1]);
                        }
                        if (!Symbol.asyncIterator) throw new TypeError('Symbol.asyncIterator is not defined.');
                        var i,
                            g = generator.apply(thisArg, _arguments || []),
                            q = [];
                        return (
                            (i = {}),
                            verb('next'),
                            verb('throw'),
                            verb('return'),
                            (i[Symbol.asyncIterator] = function () {
                                return this;
                            }),
                            i
                        );
                    }
                    function __asyncDelegator(o) {
                        function verb(n, f) {
                            i[n] = o[n]
                                ? function (v) {
                                      return (p = !p)
                                          ? { value: __await(o[n](v)), done: 'return' === n }
                                          : f
                                          ? f(v)
                                          : v;
                                  }
                                : f;
                        }
                        var i, p;
                        return (
                            (i = {}),
                            verb('next'),
                            verb('throw', function (e) {
                                throw e;
                            }),
                            verb('return'),
                            (i[Symbol.iterator] = function () {
                                return this;
                            }),
                            i
                        );
                    }
                    function __asyncValues(o) {
                        function verb(n) {
                            i[n] =
                                o[n] &&
                                function (v) {
                                    return new Promise(function (resolve, reject) {
                                        (v = o[n](v)), settle(resolve, reject, v.done, v.value);
                                    });
                                };
                        }
                        function settle(resolve, reject, d, v) {
                            Promise.resolve(v).then(function (v) {
                                resolve({ value: v, done: d });
                            }, reject);
                        }
                        if (!Symbol.asyncIterator) throw new TypeError('Symbol.asyncIterator is not defined.');
                        var i,
                            m = o[Symbol.asyncIterator];
                        return m
                            ? m.call(o)
                            : ((o = __values(o)),
                              (i = {}),
                              verb('next'),
                              verb('throw'),
                              verb('return'),
                              (i[Symbol.asyncIterator] = function () {
                                  return this;
                              }),
                              i);
                    }
                    function __makeTemplateObject(cooked, raw) {
                        return (
                            Object.defineProperty
                                ? Object.defineProperty(cooked, 'raw', { value: raw })
                                : (cooked.raw = raw),
                            cooked
                        );
                    }
                    function __importStar(mod) {
                        if (mod && mod.__esModule) return mod;
                        var result = {};
                        if (null != mod)
                            for (var k in mod)
                                'default' !== k &&
                                    Object.prototype.hasOwnProperty.call(mod, k) &&
                                    __createBinding(result, mod, k);
                        return __setModuleDefault(result, mod), result;
                    }
                    function __importDefault(mod) {
                        return mod && mod.__esModule ? mod : { default: mod };
                    }
                    function __classPrivateFieldGet(receiver, state, kind, f) {
                        if ('a' === kind && !f) throw new TypeError('Private accessor was defined without a getter');
                        if ('function' == typeof state ? receiver !== state || !f : !state.has(receiver))
                            throw new TypeError(
                                'Cannot read private member from an object whose class did not declare it',
                            );
                        return 'm' === kind ? f : 'a' === kind ? f.call(receiver) : f ? f.value : state.get(receiver);
                    }
                    function __classPrivateFieldSet(receiver, state, value, kind, f) {
                        if ('m' === kind) throw new TypeError('Private method is not writable');
                        if ('a' === kind && !f) throw new TypeError('Private accessor was defined without a setter');
                        if ('function' == typeof state ? receiver !== state || !f : !state.has(receiver))
                            throw new TypeError(
                                'Cannot write private member to an object whose class did not declare it',
                            );
                        return (
                            'a' === kind ? f.call(receiver, value) : f ? (f.value = value) : state.set(receiver, value),
                            value
                        );
                    }
                    __webpack_require__.r(__webpack_exports__),
                        __webpack_require__.d(__webpack_exports__, {
                            __assign: function () {
                                return _assign;
                            },
                            __asyncDelegator: function () {
                                return __asyncDelegator;
                            },
                            __asyncGenerator: function () {
                                return __asyncGenerator;
                            },
                            __asyncValues: function () {
                                return __asyncValues;
                            },
                            __await: function () {
                                return __await;
                            },
                            __awaiter: function () {
                                return __awaiter;
                            },
                            __classPrivateFieldGet: function () {
                                return __classPrivateFieldGet;
                            },
                            __classPrivateFieldSet: function () {
                                return __classPrivateFieldSet;
                            },
                            __createBinding: function () {
                                return __createBinding;
                            },
                            __decorate: function () {
                                return __decorate;
                            },
                            __exportStar: function () {
                                return __exportStar;
                            },
                            __extends: function () {
                                return __extends;
                            },
                            __generator: function () {
                                return __generator;
                            },
                            __importDefault: function () {
                                return __importDefault;
                            },
                            __importStar: function () {
                                return __importStar;
                            },
                            __makeTemplateObject: function () {
                                return __makeTemplateObject;
                            },
                            __metadata: function () {
                                return __metadata;
                            },
                            __param: function () {
                                return __param;
                            },
                            __read: function () {
                                return __read;
                            },
                            __rest: function () {
                                return __rest;
                            },
                            __spread: function () {
                                return __spread;
                            },
                            __spreadArray: function () {
                                return __spreadArray;
                            },
                            __spreadArrays: function () {
                                return __spreadArrays;
                            },
                            __values: function () {
                                return __values;
                            },
                        });
                    var _extendStatics = function (d, b) {
                            return (
                                (_extendStatics =
                                    Object.setPrototypeOf ||
                                    ({ __proto__: [] } instanceof Array &&
                                        function (d, b) {
                                            d.__proto__ = b;
                                        }) ||
                                    function (d, b) {
                                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (d[p] = b[p]);
                                    }),
                                _extendStatics(d, b)
                            );
                        },
                        _assign = function () {
                            return (
                                (_assign =
                                    Object.assign ||
                                    function (t) {
                                        for (var s, i = 1, n = arguments.length; i < n; i++)
                                            for (var p in ((s = arguments[i]), s))
                                                Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
                                        return t;
                                    }),
                                _assign.apply(this, arguments)
                            );
                        },
                        __createBinding = Object.create
                            ? function (o, m, k, k2) {
                                  void 0 === k2 && (k2 = k),
                                      Object.defineProperty(o, k2, {
                                          enumerable: !0,
                                          get: function () {
                                              return m[k];
                                          },
                                      });
                              }
                            : function (o, m, k, k2) {
                                  void 0 === k2 && (k2 = k), (o[k2] = m[k]);
                              },
                        __setModuleDefault = Object.create
                            ? function (o, v) {
                                  Object.defineProperty(o, 'default', { enumerable: !0, value: v });
                              }
                            : function (o, v) {
                                  o.default = v;
                              };
                },
                780: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    'use strict';
                    function utils_invariantIntlContext(intl) {
                        (0, utils.a)(
                            intl,
                            '[React Intl] Could not find required `intl` object. <IntlProvider> needs to exist in the component ancestry.',
                        );
                    }
                    function shallowEqual(objA, objB) {
                        if (objA === objB) return !0;
                        if (!objA || !objB) return !1;
                        var aKeys = Object.keys(objA),
                            bKeys = Object.keys(objB),
                            len = aKeys.length;
                        if (bKeys.length !== len) return !1;
                        for (var i = 0; i < len; i++) {
                            var key = aKeys[i];
                            if (objA[key] !== objB[key] || !Object.prototype.hasOwnProperty.call(objB, key)) return !1;
                        }
                        return !0;
                    }
                    function useIntl() {
                        var intl = external_react_.useContext(Context);
                        return utils_invariantIntlContext(intl), intl;
                    }
                    function areEqual(prevProps, nextProps) {
                        var values = prevProps.values,
                            otherProps = (0, tslib_es6.__rest)(prevProps, ['values']),
                            nextValues = nextProps.values,
                            nextOtherProps = (0, tslib_es6.__rest)(nextProps, ['values']);
                        return shallowEqual(nextValues, values) && shallowEqual(otherProps, nextOtherProps);
                    }
                    function FormattedMessage(props) {
                        var intl = useIntl(),
                            formatMessage = intl.formatMessage,
                            _a = intl.textComponent,
                            Text = void 0 === _a ? external_react_.Fragment : _a,
                            id = props.id,
                            description = props.description,
                            defaultMessage = props.defaultMessage,
                            values = props.values,
                            children = props.children,
                            _b = props.tagName,
                            Component = void 0 === _b ? Text : _b,
                            ignoreTag = props.ignoreTag,
                            descriptor = { id: id, description: description, defaultMessage: defaultMessage },
                            nodes = formatMessage(descriptor, values, { ignoreTag: ignoreTag });
                        return (
                            Array.isArray(nodes) || (nodes = [nodes]),
                            'function' == typeof children
                                ? children(nodes)
                                : Component
                                ? external_react_.createElement.apply(
                                      external_react_,
                                      (0, tslib_es6.__spreadArray)([Component, null], nodes),
                                  )
                                : external_react_.createElement(external_react_.Fragment, null, nodes)
                        );
                    }
                    function processIntlConfig(config) {
                        return {
                            locale: config.locale,
                            timeZone: config.timeZone,
                            formats: config.formats,
                            textComponent: config.textComponent,
                            messages: config.messages,
                            defaultLocale: config.defaultLocale,
                            defaultFormats: config.defaultFormats,
                            onError: config.onError,
                            wrapRichTextChunksInFragment: config.wrapRichTextChunksInFragment,
                            defaultRichTextElements: config.defaultRichTextElements,
                        };
                    }
                    function assignUniqueKeysToFormatXMLElementFnArgument(values) {
                        return values
                            ? Object.keys(values).reduce(function (acc, k) {
                                  var formatXMLElementFn,
                                      v = values[k];
                                  return (
                                      (acc[k] = (0, formatters.c)(v)
                                          ? ((formatXMLElementFn = v),
                                            function (parts) {
                                                return formatXMLElementFn(external_react_.Children.toArray(parts));
                                            })
                                          : v),
                                      acc
                                  );
                              }, {})
                            : values;
                    }
                    function _nonIterableSpread() {
                        throw new TypeError(
                            'Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.',
                        );
                    }
                    function _iterableToArray(iter) {
                        if (
                            ('undefined' != typeof Symbol && null != iter[Symbol.iterator]) ||
                            null != iter['@@iterator']
                        )
                            return Array.from(iter);
                    }
                    function _arrayWithoutHoles(arr) {
                        if (Array.isArray(arr)) return _arrayLikeToArray(arr);
                    }
                    function _slicedToArray(arr, i) {
                        return (
                            _arrayWithHoles(arr) ||
                            _iterableToArrayLimit(arr, i) ||
                            _unsupportedIterableToArray(arr, i) ||
                            _nonIterableRest()
                        );
                    }
                    function _nonIterableRest() {
                        throw new TypeError(
                            'Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.',
                        );
                    }
                    function _unsupportedIterableToArray(o, minLen) {
                        if (o) {
                            if ('string' == typeof o) return _arrayLikeToArray(o, minLen);
                            var n = Object.prototype.toString.call(o).slice(8, -1);
                            return (
                                'Object' === n && o.constructor && (n = o.constructor.name),
                                'Map' === n || 'Set' === n
                                    ? Array.from(o)
                                    : 'Arguments' === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                                    ? _arrayLikeToArray(o, minLen)
                                    : void 0
                            );
                        }
                    }
                    function _arrayLikeToArray(arr, len) {
                        (null == len || len > arr.length) && (len = arr.length);
                        for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
                        return arr2;
                    }
                    function _iterableToArrayLimit(arr, i) {
                        var _i =
                            null == arr
                                ? null
                                : ('undefined' != typeof Symbol && arr[Symbol.iterator]) || arr['@@iterator'];
                        if (null != _i) {
                            var _s,
                                _e,
                                _arr = [],
                                _n = !0,
                                _d = !1;
                            try {
                                for (
                                    _i = _i.call(arr);
                                    !(_n = (_s = _i.next()).done) && (_arr.push(_s.value), !i || _arr.length !== i);
                                    _n = !0
                                );
                            } catch (err) {
                                (_d = !0), (_e = err);
                            } finally {
                                try {
                                    _n || null == _i.return || _i.return();
                                } finally {
                                    if (_d) throw _e;
                                }
                            }
                            return _arr;
                        }
                    }
                    function _arrayWithHoles(arr) {
                        if (Array.isArray(arr)) return arr;
                    }
                    __webpack_require__.r(__webpack_exports__),
                        __webpack_require__.d(__webpack_exports__, {
                            WidgetSettings: function () {
                                return WidgetSettings;
                            },
                        });
                    var external_react_ = __webpack_require__(650),
                        external_react_default = __webpack_require__.n(external_react_),
                        IntlContext = external_react_.createContext(null),
                        IntlProvider = (IntlContext.Consumer, IntlContext.Provider),
                        Provider = IntlProvider,
                        Context = IntlContext,
                        tslib_es6 = __webpack_require__(763),
                        utils = __webpack_require__(656),
                        src_utils = __webpack_require__(846),
                        DEFAULT_INTL_CONFIG = (0, tslib_es6.__assign)((0, tslib_es6.__assign)({}, src_utils.a), {
                            textComponent: external_react_.Fragment,
                        });
                    FormattedMessage.displayName = 'FormattedMessage';
                    var MemoizedFormattedMessage = external_react_.memo(FormattedMessage, areEqual);
                    MemoizedFormattedMessage.displayName = 'MemoizedFormattedMessage';
                    var message = MemoizedFormattedMessage,
                        src_message = __webpack_require__(75),
                        create_intl = __webpack_require__(165),
                        formatters = __webpack_require__(115),
                        formatMessage = function (config, formatters, descriptor, rawValues) {
                            for (var rest = [], _i = 4; _i < arguments.length; _i++) rest[_i - 4] = arguments[_i];
                            var values = assignUniqueKeysToFormatXMLElementFnArgument(rawValues),
                                chunks = src_message.a.apply(
                                    void 0,
                                    (0, tslib_es6.__spreadArray)([config, formatters, descriptor, values], rest),
                                );
                            return Array.isArray(chunks) ? external_react_.Children.toArray(chunks) : chunks;
                        },
                        createIntl = function (_a, cache) {
                            var rawDefaultRichTextElements = _a.defaultRichTextElements,
                                config = (0, tslib_es6.__rest)(_a, ['defaultRichTextElements']),
                                defaultRichTextElements = assignUniqueKeysToFormatXMLElementFnArgument(
                                    rawDefaultRichTextElements,
                                ),
                                coreIntl = (0, create_intl.a)(
                                    (0, tslib_es6.__assign)(
                                        (0, tslib_es6.__assign)(
                                            (0, tslib_es6.__assign)({}, DEFAULT_INTL_CONFIG),
                                            config,
                                        ),
                                        { defaultRichTextElements: defaultRichTextElements },
                                    ),
                                    cache,
                                );
                            return (0, tslib_es6.__assign)((0, tslib_es6.__assign)({}, coreIntl), {
                                formatMessage: formatMessage.bind(
                                    null,
                                    {
                                        locale: coreIntl.locale,
                                        timeZone: coreIntl.timeZone,
                                        formats: coreIntl.formats,
                                        defaultLocale: coreIntl.defaultLocale,
                                        defaultFormats: coreIntl.defaultFormats,
                                        messages: coreIntl.messages,
                                        onError: coreIntl.onError,
                                        defaultRichTextElements: defaultRichTextElements,
                                    },
                                    coreIntl.formatters,
                                ),
                            });
                        },
                        provider_IntlProvider = (function (_super) {
                            function IntlProvider() {
                                var _this = (null !== _super && _super.apply(this, arguments)) || this;
                                return (
                                    (_this.cache = (0, src_utils.c)()),
                                    (_this.state = {
                                        cache: _this.cache,
                                        intl: createIntl(processIntlConfig(_this.props), _this.cache),
                                        prevConfig: processIntlConfig(_this.props),
                                    }),
                                    _this
                                );
                            }
                            return (
                                (0, tslib_es6.__extends)(IntlProvider, _super),
                                (IntlProvider.getDerivedStateFromProps = function (props, _a) {
                                    var prevConfig = _a.prevConfig,
                                        cache = _a.cache,
                                        config = processIntlConfig(props);
                                    return shallowEqual(prevConfig, config)
                                        ? null
                                        : { intl: createIntl(config, cache), prevConfig: config };
                                }),
                                (IntlProvider.prototype.render = function () {
                                    return (
                                        utils_invariantIntlContext(this.state.intl),
                                        external_react_.createElement(
                                            Provider,
                                            { value: this.state.intl },
                                            this.props.children,
                                        )
                                    );
                                }),
                                (IntlProvider.displayName = 'IntlProvider'),
                                (IntlProvider.defaultProps = DEFAULT_INTL_CONFIG),
                                IntlProvider
                            );
                        })(external_react_.PureComponent),
                        provider = provider_IntlProvider,
                        react_ = __webpack_require__(432),
                        external_lumapps_sdk_js_ = __webpack_require__(224),
                        en_namespaceObject = JSON.parse(
                            '{"title":"Lorem Picsum","sub_title":"Sample widget","description":"This is a tiny example of all the things you can do with a LumApps widget","errors.retrieve_user":"An error occurred while retrieving user","errors.dismiss":"Dismiss","settings.image_id":"Image identifier","settings.grey":"Display a grey scale image","settings.blur":"Display a blurry image","settings.nonews_value_title":"List Items","settings.nonews_value_desc":"Adjust the number of list items to display","settings.excerpt_value_title":"Excerpt value","settings.excerpt_value_desc":"Adjust the number of characters to show in the news excerpt","settings.image":"Display a default SharePoint image"}',
                        ),
                        fr_namespaceObject = JSON.parse(
                            '{"title":"Lorem Picsum","sub_title":"Exemple de widget","description":"Ceci est un petit exemple de ce qu\'il est possible de faire avec les widgets LumApps","errors.retrieve_user":"Une erreur est survenue au moment de récupérer l\'utilisateur","errors.dismiss":"Fermer","settings.image_id":"ID de l\'image","settings.grey":"Noir et blanc","settings.blur":"Flou","settings.blur_value_title":"Valeur du flou","settings.blur_value_desc":"Ajuster la valeur du flou"}',
                        ),
                        injectStylesIntoStyleTag = __webpack_require__(796),
                        injectStylesIntoStyleTag_default = __webpack_require__.n(injectStylesIntoStyleTag),
                        styleDomAPI = __webpack_require__(715),
                        styleDomAPI_default = __webpack_require__.n(styleDomAPI),
                        insertBySelector = __webpack_require__(578),
                        insertBySelector_default = __webpack_require__.n(insertBySelector),
                        setAttributesWithoutAttributes = __webpack_require__(372),
                        setAttributesWithoutAttributes_default = __webpack_require__.n(setAttributesWithoutAttributes),
                        insertStyleElement = __webpack_require__(849),
                        insertStyleElement_default = __webpack_require__.n(insertStyleElement),
                        styleTagTransform = __webpack_require__(151),
                        styleTagTransform_default = __webpack_require__.n(styleTagTransform),
                        App = __webpack_require__(622),
                        options = {};
                    (options.styleTagTransform = styleTagTransform_default()),
                        (options.setAttributes = setAttributesWithoutAttributes_default()),
                        (options.insert = insertBySelector_default().bind(null, 'head')),
                        (options.domAPI = styleDomAPI_default()),
                        (options.insertStyleElement = insertStyleElement_default());
                    injectStylesIntoStyleTag_default()(App.a, options), App.a && App.a.locals && App.a.locals;
                    var external_axios_ = __webpack_require__(873),
                        external_axios_default = __webpack_require__.n(external_axios_),
                        WithIntlSettings = function (_ref) {
                            var _ref$properties = _ref.properties,
                                properties = void 0 === _ref$properties ? {} : _ref$properties,
                                exportProp = _ref.exportProp,
                                _useState = (useIntl(), (0, external_react_.useState)(properties.siteId)),
                                _useState2 = _slicedToArray(_useState, 2),
                                siteId = _useState2[0],
                                setSiteId = _useState2[1],
                                _useState3 = (0, external_react_.useState)(properties.listId),
                                _useState4 = _slicedToArray(_useState3, 2),
                                listId = _useState4[0],
                                setListId = _useState4[1],
                                _useState5 = (0, external_react_.useState)(properties.columnId),
                                _useState6 = _slicedToArray(_useState5, 2),
                                _useState7 =
                                    (_useState6[0], _useState6[1], (0, external_react_.useState)(properties.listName)),
                                _useState8 = _slicedToArray(_useState7, 2),
                                listName = _useState8[0],
                                setListName = _useState8[1],
                                _useState9 = (0, external_react_.useState)(properties.siteName),
                                _useState10 = _slicedToArray(_useState9, 2),
                                setSiteName = (_useState10[0], _useState10[1]),
                                _useState11 = (0, external_react_.useState)(properties.siteDesc),
                                _useState12 = _slicedToArray(_useState11, 2),
                                siteDesc = _useState12[0],
                                setSiteDesc = _useState12[1],
                                _useState13 = (0, external_react_.useState)(properties.siteSearch),
                                _useState14 = _slicedToArray(_useState13, 2),
                                siteSearch = _useState14[0],
                                _useState15 = (_useState14[1], (0, external_react_.useState)(properties.sites)),
                                _useState16 = _slicedToArray(_useState15, 2),
                                sites = _useState16[0],
                                _useState17 = (_useState16[1], (0, external_react_.useState)('')),
                                _useState18 = _slicedToArray(_useState17, 2),
                                url = _useState18[0],
                                setSiteURL = _useState18[1],
                                _useState19 = (0, external_react_.useState)(''),
                                _useState20 = _slicedToArray(_useState19, 2),
                                infolist = _useState20[0],
                                setInfoList = _useState20[1],
                                _useState21 = (0, external_react_.useState)(''),
                                _useState22 = _slicedToArray(_useState21, 2),
                                interest = _useState22[0],
                                setInterest = _useState22[1],
                                _useState23 = (0, external_react_.useState)(''),
                                _useState24 = _slicedToArray(_useState23, 2),
                                response = _useState24[0],
                                setResponse = _useState24[1],
                                _useState25 = (0, external_react_.useState)(''),
                                _useState26 = _slicedToArray(_useState25, 2),
                                lists = _useState26[0],
                                setLists = _useState26[1],
                                _useState27 = (0, external_react_.useState)(''),
                                _useState28 = _slicedToArray(_useState27, 2),
                                columns = _useState28[0],
                                setListColumns = _useState28[1],
                                _useState29 = (0, external_react_.useState)(properties.excerpt || 1),
                                _useState30 = _slicedToArray(_useState29, 2),
                                excerpt = _useState30[0],
                                _useState31 = (_useState30[1], (0, external_react_.useState)(properties.nonews || 1)),
                                _useState32 = _slicedToArray(_useState31, 2),
                                nonews = _useState32[0],
                                setNonews = _useState32[1],
                                _useState33 = (0, external_react_.useState)(properties.useimage || !1),
                                _useState34 = _slicedToArray(_useState33, 2),
                                useimage = _useState34[0],
                                _useState35 = (_useState34[1], (0, external_react_.useState)(properties.nonewsId)),
                                _useState36 = _slicedToArray(_useState35, 2),
                                nonewsId = _useState36[0],
                                _useState37 =
                                    (_useState36[1], (0, external_react_.useState)(properties.useGreyScale || !1)),
                                _useState38 = _slicedToArray(_useState37, 2),
                                useGreyScale = _useState38[0],
                                _useState39 = (_useState38[1], (0, external_react_.useState)(properties.useBlur || !1)),
                                _useState40 = _slicedToArray(_useState39, 2),
                                useBlur = _useState40[0],
                                _useState41 = (_useState40[1], (0, external_react_.useState)(properties.blur || 1)),
                                _useState42 = _slicedToArray(_useState41, 2),
                                blur = _useState42[0],
                                _React$useState = (_useState42[1], external_react_default().useState([])),
                                _React$useState2 = _slicedToArray(_React$useState, 2),
                                values = _React$useState2[0],
                                setValues = _React$useState2[1],
                                debouncedImageId = (0, external_lumapps_sdk_js_.useDebounce)(nonewsId, 800),
                                _useState43 = (0, external_react_.useState)('12da1e76-c564-44ad-8f98-06a3cda8f3b4'),
                                _useState44 = _slicedToArray(_useState43, 2),
                                tenant = _useState44[0],
                                setTenant = _useState44[1],
                                _useState45 = (0, external_react_.useState)('b4463410-6089-42f4-9445-a22d63051845'),
                                _useState46 = _slicedToArray(_useState45, 2),
                                appid = _useState46[0],
                                setAppid = _useState46[1],
                                _useState47 = (0, external_react_.useState)('Cu~7Q~9c-kZl3D21-74Np5gVYh6v0NhPQfXzP'),
                                _useState48 = _slicedToArray(_useState47, 2),
                                secret = _useState48[0],
                                setSecret = _useState48[1],
                                _useState49 = (0, external_react_.useState)(''),
                                _useState50 = _slicedToArray(_useState49, 2),
                                listitems = _useState50[0],
                                setListItems = _useState50[1];
                            (0, external_lumapps_sdk_js_.useExportProps)(tenant, 'tenant', properties, exportProp),
                                (0, external_lumapps_sdk_js_.useExportProps)(appid, 'appid', properties, exportProp),
                                (0, external_lumapps_sdk_js_.useExportProps)(secret, 'secret', properties, exportProp),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    listitems,
                                    'listitems',
                                    properties,
                                    exportProp,
                                ),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    infolist,
                                    'infolist',
                                    properties,
                                    exportProp,
                                ),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    debouncedImageId,
                                    'nonewsId',
                                    properties,
                                    exportProp,
                                ),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    useGreyScale,
                                    'useGreyScale',
                                    properties,
                                    exportProp,
                                ),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    useBlur,
                                    'useBlur',
                                    properties,
                                    exportProp,
                                ),
                                (0, external_lumapps_sdk_js_.useExportProps)(blur, 'blur', properties, exportProp),
                                (0, external_lumapps_sdk_js_.useExportProps)(lists, 'lists', properties, exportProp),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    sites,
                                    'foundsites',
                                    properties,
                                    exportProp,
                                ),
                                (0, external_lumapps_sdk_js_.useExportProps)(url, 'siteurl', properties, exportProp),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    excerpt,
                                    'excerpt',
                                    properties,
                                    exportProp,
                                ),
                                (0, external_lumapps_sdk_js_.useExportProps)(nonews, 'nonews', properties, exportProp),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    useimage,
                                    'useimage',
                                    properties,
                                    exportProp,
                                ),
                                (0, external_lumapps_sdk_js_.useExportProps)(
                                    values,
                                    'listcols',
                                    properties,
                                    exportProp,
                                );
                            var anchorSiteRef = external_react_default().useRef(null),
                                anchorListRef = external_react_default().useRef(null),
                                _React$useState3 =
                                    (external_react_default().useRef(null), external_react_default().useState(!1)),
                                _React$useState4 = _slicedToArray(_React$useState3, 2),
                                isSiteOpen = _React$useState4[0],
                                setSiteIsOpen = _React$useState4[1],
                                _React$useState5 = external_react_default().useState(!1),
                                _React$useState6 = _slicedToArray(_React$useState5, 2),
                                isListOpen = _React$useState6[0],
                                setListIsOpen = _React$useState6[1],
                                _React$useState7 = external_react_default().useState(!1),
                                _React$useState8 = _slicedToArray(_React$useState7, 2),
                                toggleSiteMenu =
                                    (_React$useState8[0],
                                    _React$useState8[1],
                                    function () {
                                        return setSiteIsOpen(!isSiteOpen);
                                    }),
                                toggleListMenu = function () {
                                    return setListIsOpen(!isListOpen);
                                },
                                closeSiteMenu = function () {
                                    return setSiteIsOpen(!1);
                                },
                                closeListMenu = function () {
                                    return setListIsOpen(!1);
                                },
                                _useState51 = (0, external_react_.useState)(!1),
                                _useState52 = _slicedToArray(_useState51, 2),
                                showDDL = _useState52[0],
                                setDDL = _useState52[1],
                                _useState53 = (0, external_react_.useState)(!1),
                                _useState54 = _slicedToArray(_useState53, 2),
                                showDDLists = _useState54[0],
                                setDDLists = _useState54[1],
                                _useState55 = (0, external_react_.useState)(!1),
                                _useState56 = _slicedToArray(_useState55, 2),
                                showDDCols = _useState56[0],
                                setDDCols = _useState56[1],
                                _useState57 = (0, external_react_.useState)(!1),
                                _useState58 = _slicedToArray(_useState57, 2),
                                showComm = _useState58[0],
                                setComments = _useState58[1],
                                _useState59 = (0, external_react_.useState)(!1),
                                _useState60 = _slicedToArray(_useState59, 2),
                                _useState61 = (_useState60[0], _useState60[1], (0, external_react_.useState)(!1)),
                                _useState62 = _slicedToArray(_useState61, 2),
                                _useState63 = (_useState62[0], _useState62[1], (0, external_react_.useState)(!1)),
                                _useState64 = _slicedToArray(_useState63, 2);
                            _useState64[0], _useState64[1];
                            console.log('SEARCH ' + siteSearch);
                            var search,
                                article,
                                onSiteMenuSelected = function (item, site, url) {
                                    return function () {
                                        setSiteId(item),
                                            setSiteName(site),
                                            setSiteDesc(
                                                'You have selected the site: ' +
                                                    site +
                                                    '. Only modern sites will display news items. Please ensure you have selected a modern site using news site pages',
                                            ),
                                            setSiteURL(url),
                                            closeSiteMenu();
                                    };
                                },
                                onListMenuSelected = function (item, list, url) {
                                    return function () {
                                        setListName(list),
                                            setSiteDesc(
                                                'You have selected the list: ' +
                                                    list +
                                                    '. Please specify below the number of items to show',
                                            ),
                                            setComments(!0),
                                            setListId(item),
                                            closeListMenu();
                                    };
                                },
                                _useState65 = (0, external_react_.useState)(!1),
                                _useState66 = _slicedToArray(_useState65, 2),
                                isOpen = _useState66[0],
                                setOpen = _useState66[1],
                                closeSelect = function () {
                                    return setOpen(!1);
                                },
                                toggleSelect = function () {
                                    return setOpen(!isOpen);
                                },
                                clearSelected = function (event, value) {
                                    null == event || event.stopPropagation(),
                                        setValues(
                                            value
                                                ? values.filter(function (val) {
                                                      return val !== value;
                                                  })
                                                : [],
                                        );
                                },
                                selectItem = function (item) {
                                    return function () {
                                        var arr;
                                        values.includes(item)
                                            ? clearSelected(void 0, item)
                                            : setValues(
                                                  [].concat(
                                                      ((arr = values),
                                                      _arrayWithoutHoles(arr) ||
                                                          _iterableToArray(arr) ||
                                                          _unsupportedIterableToArray(arr) ||
                                                          _nonIterableSpread()),
                                                      [item],
                                                  ),
                                              );
                                    };
                                },
                                ten = external_react_default().createElement(
                                    'div',
                                    { className: 'searchcontainer' },
                                    external_react_default().createElement('input', {
                                        className: 'searchInput',
                                        type: 'text',
                                        placeholder: 'Enter your Tenant ID',
                                        value: tenant,
                                        onChange: function (event) {
                                            setTenant(event.target.value);
                                        },
                                        style: { width: '270px' },
                                    }),
                                ),
                                app = external_react_default().createElement(
                                    'div',
                                    { className: 'searchcontainer' },
                                    external_react_default().createElement('input', {
                                        className: 'searchInput',
                                        type: 'text',
                                        placeholder: 'Enter your Application ID',
                                        value: appid,
                                        onChange: function (event) {
                                            setAppid(event.target.value);
                                        },
                                        style: { width: '270px' },
                                    }),
                                ),
                                sec = external_react_default().createElement(
                                    'div',
                                    { className: 'searchcontainer' },
                                    external_react_default().createElement('input', {
                                        className: 'searchInput',
                                        type: 'text',
                                        placeholder: 'Enter your Secret',
                                        value: secret,
                                        onChange: function (event) {
                                            setSecret(event.target.value);
                                        },
                                        style: { width: '270px' },
                                    }),
                                ),
                                searchBox =
                                    ((search = interest),
                                    (article = { text: search, appid: appid, secret: secret, tenentid: tenant }),
                                    (0, external_react_.useEffect)(function () {}, [interest]),
                                    external_react_default().createElement(
                                        'div',
                                        { className: 'searchcontainer' },
                                        external_react_default().createElement('input', {
                                            className: 'searchInput',
                                            type: 'text',
                                            placeholder: 'Enter a site name',
                                            value: interest,
                                            onChange: function (event) {
                                                setInterest(event.target.value),
                                                    console.log(
                                                        '___________HANDLE SITE SELECTION: ' + event.target.value,
                                                    );
                                            },
                                        }),
                                        external_react_default().createElement(
                                            react_.Button,
                                            {
                                                onClick: function () {
                                                    external_axios_default()
                                                        .post(
                                                            'https://dave-master-services.herokuapp.com/microsoft/siteSearch',
                                                            article,
                                                        )
                                                        .then(function (res) {
                                                            setResponse(res.data.value), setDDL(!0);
                                                        })
                                                        .catch(function (err) {
                                                            console.log(err);
                                                        });
                                                },
                                                className: 'searchbutton',
                                                disabled: '' === interest,
                                            },
                                            'Search',
                                        ),
                                    )),
                                searchBut = showDDL
                                    ? external_react_default().createElement(
                                          'div',
                                          { className: 'searchcontainer' },
                                          external_react_default().createElement(
                                              react_.Button,
                                              {
                                                  ref: anchorSiteRef,
                                                  onClick: toggleSiteMenu,
                                                  disabled: '' === interest,
                                              },
                                              'Choose SharePoint Site',
                                          ),
                                      )
                                    : external_react_default().createElement('div', null),
                                dropDown = (function (res) {
                                    for (var list1 = new Array(), i = 0; i < res.length; i++) {
                                        var obj = {};
                                        (obj.siteName = res[i].displayName),
                                            (obj.siteID = res[i].id),
                                            (obj.url = res[i].webUrl),
                                            list1.push(obj);
                                    }
                                    return showDDL
                                        ? external_react_default().createElement(
                                              react_.Dropdown,
                                              { isOpen: isSiteOpen, onClose: closeSiteMenu, anchorRef: anchorSiteRef },
                                              external_react_default().createElement(
                                                  react_.List,
                                                  null,
                                                  list1.length > 0
                                                      ? list1.map(function (choice) {
                                                            return external_react_default().createElement(
                                                                react_.ListItem,
                                                                {
                                                                    isSelected: siteId === choice.siteID,
                                                                    key: choice.siteID,
                                                                    onItemSelected: onSiteMenuSelected(
                                                                        choice.siteID,
                                                                        choice.siteName,
                                                                        choice.url,
                                                                    ),
                                                                    size: react_.Size.tiny,
                                                                    value: choice.siteName,
                                                                },
                                                                choice.siteName,
                                                            );
                                                        })
                                                      : [
                                                            external_react_default().createElement(
                                                                react_.ListItem,
                                                                { key: 0, size: react_.Size.tiny },
                                                                'No data',
                                                            ),
                                                        ],
                                              ),
                                          )
                                        : external_react_default().createElement('div', null);
                                })(response),
                                sitelists = (function (siteid) {
                                    siteid = JSON.stringify(siteid);
                                    var article = { text: siteid, appid: appid, secret: secret, tenentid: tenant };
                                    (0, external_react_.useEffect)(
                                        function () {
                                            void 0 !== siteid &&
                                                external_axios_default()
                                                    .post(
                                                        'https://dave-master-services.herokuapp.com/microsoft/getLists',
                                                        article,
                                                    )
                                                    .then(function (res) {
                                                        setLists(res.data.value), res.data.value, setDDLists(!0);
                                                    })
                                                    .catch(function (err) {
                                                        console.log(err);
                                                    });
                                        },
                                        [siteid],
                                    );
                                })(siteId),
                                infoList = (function (siteid) {
                                    var article = { sid: siteid, appid: appid, secret: secret, tenentid: tenant };
                                    (0, external_react_.useEffect)(
                                        function () {
                                            void 0 !== siteid &&
                                                external_axios_default()
                                                    .post(
                                                        'https://dave-master-services.herokuapp.com/microsoft/getInfoList',
                                                        article,
                                                    )
                                                    .then(function (res) {
                                                        setInfoList(res.data.value[0].id),
                                                            console.log(
                                                                '________SITE INFO LIST: ' +
                                                                    JSON.stringify(res.data.value[0].id),
                                                            ),
                                                            res.data.value;
                                                    })
                                                    .catch(function (err) {
                                                        console.log(err);
                                                    });
                                        },
                                        [siteid],
                                    );
                                })(siteId),
                                listBut = showDDLists
                                    ? external_react_default().createElement(
                                          'div',
                                          { className: 'listcontainer' },
                                          external_react_default().createElement(
                                              react_.Button,
                                              {
                                                  ref: anchorListRef,
                                                  onClick: toggleListMenu,
                                                  disabled: '' === interest,
                                              },
                                              'Choose SharePoint List',
                                          ),
                                      )
                                    : external_react_default().createElement('div', null),
                                dropDownLists = (function (res) {
                                    for (var list1 = new Array(), i = 0; i < res.length; i++) {
                                        var obj = {};
                                        (obj.title = res[i].displayName),
                                            (obj.id = res[i].id),
                                            (obj.url = res[i].required),
                                            list1.push(obj);
                                    }
                                    return showDDLists
                                        ? external_react_default().createElement(
                                              'div',
                                              null,
                                              external_react_default().createElement(
                                                  react_.Dropdown,
                                                  {
                                                      isOpen: isListOpen,
                                                      onClose: closeListMenu,
                                                      anchorRef: anchorListRef,
                                                  },
                                                  external_react_default().createElement(
                                                      react_.List,
                                                      null,
                                                      list1.length > 0
                                                          ? list1.map(function (choice) {
                                                                return external_react_default().createElement(
                                                                    react_.ListItem,
                                                                    {
                                                                        isSelected: listId === choice.id,
                                                                        key: choice.id,
                                                                        onItemSelected: onListMenuSelected(
                                                                            choice.id,
                                                                            choice.title,
                                                                            choice.url,
                                                                        ),
                                                                        size: react_.Size.tiny,
                                                                        value: choice.title,
                                                                    },
                                                                    choice.title,
                                                                );
                                                            })
                                                          : [
                                                                external_react_default().createElement(
                                                                    react_.ListItem,
                                                                    { key: 0, size: react_.Size.tiny },
                                                                    'No data',
                                                                ),
                                                            ],
                                                  ),
                                              ),
                                          )
                                        : external_react_default().createElement('div', null);
                                })(lists),
                                cols = (function (siteid, listid) {
                                    siteid = JSON.stringify(siteid);
                                    var article = {
                                        sid: siteid,
                                        lid: listid,
                                        appid: appid,
                                        secret: secret,
                                        tenentid: tenant,
                                    };
                                    (0, external_react_.useEffect)(
                                        function () {
                                            void 0 !== listid &&
                                                external_axios_default()
                                                    .post(
                                                        'https://dave-master-services.herokuapp.com/microsoft/getListColumns',
                                                        article,
                                                    )
                                                    .then(function (res) {
                                                        setListColumns(res.data.value), res.data.value, setDDCols(!0);
                                                    })
                                                    .catch(function (err) {
                                                        console.log(err);
                                                    });
                                        },
                                        [listid],
                                    );
                                })(siteId, listId),
                                listCols = (function (res) {
                                    for (var list1 = new Array(), i = 0; i < res.length; i++) {
                                        var obj = {};
                                        (obj.title = res[i].displayName),
                                            (obj.id = res[i].id),
                                            (obj.hidden = res[i].hidden),
                                            list1.push(obj);
                                    }
                                    if (showDDCols)
                                        return external_react_default().createElement(
                                            'div',
                                            { className: 'colscontainer' },
                                            external_react_default().createElement(
                                                react_.SelectMultiple,
                                                {
                                                    style: { width: '100%' },
                                                    value: values,
                                                    isOpen: isOpen,
                                                    onDropdownClose: closeSelect,
                                                    onInputClick: toggleSelect,
                                                    label: 'Select List Columns',
                                                    placeholder: 'Select a value',
                                                    onClear: clearSelected,
                                                    clearButtonProps: { label: 'Clear' },
                                                },
                                                external_react_default().createElement(
                                                    react_.List,
                                                    null,
                                                    list1.length > 0
                                                        ? list1.map(function (choice) {
                                                              return external_react_default().createElement(
                                                                  react_.ListItem,
                                                                  {
                                                                      isSelected: values.includes(choice.title),
                                                                      key: choice.id,
                                                                      onItemSelected: selectItem(choice.title),
                                                                      size: react_.Size.tiny,
                                                                  },
                                                                  choice.title,
                                                              );
                                                          })
                                                        : [
                                                              external_react_default().createElement(
                                                                  react_.ListItem,
                                                                  { key: 0, size: react_.Size.tiny },
                                                                  'No data',
                                                              ),
                                                          ],
                                                ),
                                            ),
                                        );
                                })(columns),
                                items = (function (siteid, listid, cols) {
                                    siteid = JSON.stringify(siteid);
                                    var article = {
                                        sid: siteid,
                                        lid: listid,
                                        appid: appid,
                                        secret: secret,
                                        tenentid: tenant,
                                        columns: cols,
                                    };
                                    (0, external_react_.useEffect)(
                                        function () {
                                            cols.length > 0 &&
                                                external_axios_default()
                                                    .post(
                                                        'https://dave-master-services.herokuapp.com/microsoft/getListItems',
                                                        article,
                                                    )
                                                    .then(function (res) {
                                                        setListItems(res.data.value), res.data.value;
                                                    })
                                                    .catch(function (err) {
                                                        console.log(err);
                                                    });
                                        },
                                        [cols],
                                    );
                                })(siteId, listId, values),
                                user = (function (siteid, listid, id) {
                                    console.log('________________INFOLIST ' + infolist);
                                    var article = {
                                        sid: siteid,
                                        lid: listid,
                                        id: id,
                                        appid: appid,
                                        secret: secret,
                                        tenentid: tenant,
                                    };
                                    (0, external_react_.useEffect)(
                                        function () {
                                            '' !== infolist &&
                                                external_axios_default()
                                                    .post(
                                                        'https://dave-master-services.herokuapp.com/microsoft/getUserlookup',
                                                        article,
                                                    )
                                                    .then(function (res) {
                                                        console.log('________USER: ' + JSON.stringify(res.data)),
                                                            res.data.value;
                                                    })
                                                    .catch(function (err) {
                                                        console.log(err);
                                                    });
                                        },
                                        [infolist],
                                    );
                                })(siteId, infolist, '6'),
                                comments = showComm
                                    ? external_react_default().createElement(react_.CommentBlock, {
                                          hasActions: !0,
                                          isRelevant: !0,
                                          avatarProps: {
                                              image:
                                                  'https://www.onmsft.com/wp-content/uploads/2021/04/microsoftlistsappicon.jpg',
                                              alt: 'Avatar',
                                          },
                                          date: '',
                                          name: listName,
                                          text: siteDesc,
                                          visible: '',
                                      })
                                    : external_react_default().createElement('div', null),
                                nwsslider = showDDL
                                    ? external_react_default().createElement(react_.Slider, {
                                          label: external_react_default().createElement(message, {
                                              id: 'settings.nonews_value_title',
                                          }),
                                          helper: external_react_default().createElement(message, {
                                              id: 'settings.nonews_value_desc',
                                          }),
                                          max: 20,
                                          min: 1,
                                          value: nonews,
                                          onChange: setNonews,
                                      })
                                    : external_react_default().createElement('div', null);
                            return external_react_default().createElement(
                                external_react_default().Fragment,
                                null,
                                ten,
                                app,
                                sec,
                                searchBox,
                                searchBut,
                                dropDown,
                                listBut,
                                sitelists,
                                infoList,
                                dropDownLists,
                                listCols,
                                items,
                                user,
                                comments,
                                nwsslider,
                                cols,
                            );
                        },
                        WidgetSettings = function (props) {
                            var _useLanguage = (0, external_lumapps_sdk_js_.useLanguage)(),
                                displayLanguage = _useLanguage.displayLanguage,
                                messages = { en: en_namespaceObject, fr: fr_namespaceObject },
                                lang = (0, external_react_.useMemo)(
                                    function () {
                                        return Object.keys(messages).includes(displayLanguage) ? displayLanguage : 'en';
                                    },
                                    [displayLanguage, messages],
                                );
                            return external_react_default().createElement(
                                provider,
                                { locale: lang, messages: messages[lang] },
                                external_react_default().createElement(
                                    external_lumapps_sdk_js_.PredefinedErrorBoundary,
                                    null,
                                    external_react_default().createElement(WithIntlSettings, props),
                                ),
                            );
                        };
                },
                622: function (module, __webpack_exports__, __webpack_require__) {
                    'use strict';
                    var _node_modules_lumapps_extensions_shipping_server_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
                            682,
                        ),
                        _node_modules_lumapps_extensions_shipping_server_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(
                            _node_modules_lumapps_extensions_shipping_server_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_1__,
                        ),
                        _node_modules_lumapps_extensions_shipping_server_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
                            839,
                        ),
                        _node_modules_lumapps_extensions_shipping_server_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(
                            _node_modules_lumapps_extensions_shipping_server_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__,
                        ),
                        ___CSS_LOADER_EXPORT___ = _node_modules_lumapps_extensions_shipping_server_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(
                            _node_modules_lumapps_extensions_shipping_server_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_1___default(),
                        );
                    ___CSS_LOADER_EXPORT___.push([
                        module.id,
                        '.component-widget {\r\n  position: relative;\r\n  flex: 1 0 auto;\r\n  display: flex;\r\n  flex-direction: column;\r\n  margin: 12px 0;\r\n}\r\n.widget-header__title {\r\n  font-size: 16px;\r\n  font-size: 1rem;\r\n  font-weight: 500;\r\n}\r\n.lumx-expansion-panel__wrapper\r\n{\r\n  max-height:900px !important\r\n}\r\n.searchcontainer\r\n{\r\n  width:100%;\r\n  border: solid opx red;\r\n  margin-bottom:5%;\r\n  border-bottom:1px solid rgba(0,0,0,0.1);\r\n  padding-bottom:20px;\r\n}\r\n.listcontainer\r\n{\r\n  width:100%;\r\n  border: solid 0px blue;\r\n  margin-bottom:5%;\r\n  border-bottom:1px solid rgba(0,0,0,0.1);\r\n  padding-bottom:20px;\r\n}\r\n.colscontainer\r\n{\r\n  width:100%;\r\n  border: solid 0px red;\r\n  margin-bottom:5%;\r\n  border-bottom:1px solid rgba(0,0,0,0.1);\r\n  padding-bottom:20px;\r\n}\r\n.commentBlock\r\n{\r\n  width:100%;\r\n  border: solid 0px red;\r\n  margin-bottom:5%;\r\n  border-bottom:1px solid rgba(0,0,0,0.1);\r\n  padding-bottom:20px;\r\n}\r\n.searchInput\r\n{\r\n  margin-right:5%;\r\n  height: 36px;\r\n}\r\n.chips\r\n{\r\n  display: flex;\r\n  flex-direction: row;\r\n  flex-wrap: wrap;\r\n}\r\n.newsContainer\r\n{\r\n  display: flex;\r\n  flex-direction: row;\r\n  flex-wrap: wrap;\r\n}\r\n.listContainer\r\n{\r\n  display: flex;\r\n  flex-direction: row;\r\n  flex-wrap: wrap;\r\n  border: solid 0px red;\r\n}\r\n.newsItem\r\n{\r\n  \r\n  border: solid opx red;\r\n  margin-bottom:5%;\r\n  border-bottom:0px solid rgba(0,0,0,0.1);\r\n  padding-bottom:20px;\r\n  box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;\r\n  padding:8px;\r\n \r\n  margin-right: 1%;\r\n  min-height: 200px;\r\n  flex-basis: 24%;\r\n}\r\n.newsTitle\r\n{\r\n  \r\n  font-size: 1rem;\r\n    font-weight: 500;\r\n  margin-bottom:5%;\r\n  \r\n\r\n    display: flex;\r\n    flex-direction: row;\r\n    align-items: center;\r\n    justify-content: flex-start;\r\n    margin: 0 4px;\r\n    padding: 12px 0;\r\n    border: solid rgba(0,0,0,.12);\r\n    border-width: 0 0 1px;\r\n}\r\n\r\n.newsImage\r\n{\r\n  width:90%;\r\n  margin-bottom:2%;\r\n}\r\n.hasimage\r\n{\r\n  width:200px !important;\r\n  height:200px !important;\r\n}\r\n.hasnoimage\r\n{\r\n  width:0px !important;\r\n  height:0px !important;\r\n}\r\n\r\n.newsPub\r\n{\r\n  width:90%;\r\n  margin-bottom:2%;\r\n  font-size:16px;\r\n}\r\n.url{\r\n  color: inherit;\r\n  text-decoration: none;\r\n}\r\n.excerpt\r\n{\r\n  width:90%;\r\n  margin-bottom:5%;\r\n  overflow: hidden;\r\n  display: -webkit-box;\r\n  -webkit-line-clamp: 5;\r\n  -webkit-box-orient: vertical;\r\n\r\n}\r\n.lumx-chip--size-m .lumx-chip__label {\r\n  \r\n  font-size: 12px !important;\r\n  \r\n}',
                        '',
                    ]),
                        (__webpack_exports__.a = ___CSS_LOADER_EXPORT___);
                },
                796: function (module) {
                    'use strict';
                    function getIndexByIdentifier(identifier) {
                        for (var result = -1, i = 0; i < stylesInDOM.length; i++)
                            if (stylesInDOM[i].identifier === identifier) {
                                result = i;
                                break;
                            }
                        return result;
                    }
                    function modulesToDom(list, options) {
                        for (var idCountMap = {}, identifiers = [], i = 0; i < list.length; i++) {
                            var item = list[i],
                                id = options.base ? item[0] + options.base : item[0],
                                count = idCountMap[id] || 0,
                                identifier = ''.concat(id, ' ').concat(count);
                            idCountMap[id] = count + 1;
                            var indexByIdentifier = getIndexByIdentifier(identifier),
                                obj = {
                                    css: item[1],
                                    media: item[2],
                                    sourceMap: item[3],
                                    supports: item[4],
                                    layer: item[5],
                                };
                            if (-1 !== indexByIdentifier)
                                stylesInDOM[indexByIdentifier].references++,
                                    stylesInDOM[indexByIdentifier].updater(obj);
                            else {
                                var updater = addElementStyle(obj, options);
                                (options.byIndex = i),
                                    stylesInDOM.splice(i, 0, {
                                        identifier: identifier,
                                        updater: updater,
                                        references: 1,
                                    });
                            }
                            identifiers.push(identifier);
                        }
                        return identifiers;
                    }
                    function addElementStyle(obj, options) {
                        var api = options.domAPI(options);
                        api.update(obj);
                        return function (newObj) {
                            if (newObj) {
                                if (
                                    newObj.css === obj.css &&
                                    newObj.media === obj.media &&
                                    newObj.sourceMap === obj.sourceMap &&
                                    newObj.supports === obj.supports &&
                                    newObj.layer === obj.layer
                                )
                                    return;
                                api.update((obj = newObj));
                            } else api.remove();
                        };
                    }
                    var stylesInDOM = [];
                    module.exports = function (list, options) {
                        (options = options || {}), (list = list || []);
                        var lastIdentifiers = modulesToDom(list, options);
                        return function (newList) {
                            newList = newList || [];
                            for (var i = 0; i < lastIdentifiers.length; i++) {
                                var identifier = lastIdentifiers[i],
                                    index = getIndexByIdentifier(identifier);
                                stylesInDOM[index].references--;
                            }
                            for (
                                var newLastIdentifiers = modulesToDom(newList, options), _i = 0;
                                _i < lastIdentifiers.length;
                                _i++
                            ) {
                                var _identifier = lastIdentifiers[_i],
                                    _index = getIndexByIdentifier(_identifier);
                                0 === stylesInDOM[_index].references &&
                                    (stylesInDOM[_index].updater(), stylesInDOM.splice(_index, 1));
                            }
                            lastIdentifiers = newLastIdentifiers;
                        };
                    };
                },
                578: function (module) {
                    'use strict';
                    function getTarget(target) {
                        if (void 0 === memo[target]) {
                            var styleTarget = document.querySelector(target);
                            if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement)
                                try {
                                    styleTarget = styleTarget.contentDocument.head;
                                } catch (e) {
                                    styleTarget = null;
                                }
                            memo[target] = styleTarget;
                        }
                        return memo[target];
                    }
                    var memo = {};
                    module.exports = function (insert, style) {
                        var target = getTarget(insert);
                        if (!target)
                            throw new Error(
                                "Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.",
                            );
                        target.appendChild(style);
                    };
                },
                849: function (module) {
                    'use strict';
                    module.exports = function (options) {
                        var element = document.createElement('style');
                        return (
                            options.setAttributes(element, options.attributes),
                            options.insert(element, options.options),
                            element
                        );
                    };
                },
                372: function (module, __unused_webpack_exports, __webpack_require__) {
                    'use strict';
                    module.exports = function (styleElement) {
                        var nonce = __webpack_require__.nc;
                        nonce && styleElement.setAttribute('nonce', nonce);
                    };
                },
                715: function (module) {
                    'use strict';
                    function apply(styleElement, options, obj) {
                        var css = '';
                        obj.supports && (css += '@supports ('.concat(obj.supports, ') {')),
                            obj.media && (css += '@media '.concat(obj.media, ' {'));
                        var needLayer = void 0 !== obj.layer;
                        needLayer && (css += '@layer'.concat(obj.layer.length > 0 ? ' '.concat(obj.layer) : '', ' {')),
                            (css += obj.css),
                            needLayer && (css += '}'),
                            obj.media && (css += '}'),
                            obj.supports && (css += '}');
                        var sourceMap = obj.sourceMap;
                        sourceMap &&
                            'undefined' != typeof btoa &&
                            (css += '\n/*# sourceMappingURL=data:application/json;base64,'.concat(
                                btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))),
                                ' */',
                            )),
                            options.styleTagTransform(css, styleElement, options.options);
                    }
                    function removeStyleElement(styleElement) {
                        if (null === styleElement.parentNode) return !1;
                        styleElement.parentNode.removeChild(styleElement);
                    }
                    module.exports = function (options) {
                        var styleElement = options.insertStyleElement(options);
                        return {
                            update: function (obj) {
                                apply(styleElement, options, obj);
                            },
                            remove: function () {
                                removeStyleElement(styleElement);
                            },
                        };
                    };
                },
                151: function (module) {
                    'use strict';
                    module.exports = function (css, styleElement) {
                        if (styleElement.styleSheet) styleElement.styleSheet.cssText = css;
                        else {
                            for (; styleElement.firstChild; ) styleElement.removeChild(styleElement.firstChild);
                            styleElement.appendChild(document.createTextNode(css));
                        }
                    };
                },
                432: function (module) {
                    'use strict';
                    module.exports = __WEBPACK_EXTERNAL_MODULE__432__;
                },
                873: function (module) {
                    'use strict';
                    module.exports = __WEBPACK_EXTERNAL_MODULE__873__;
                },
                224: function (module) {
                    'use strict';
                    module.exports = __WEBPACK_EXTERNAL_MODULE__224__;
                },
                650: function (module) {
                    'use strict';
                    module.exports = __WEBPACK_EXTERNAL_MODULE__650__;
                },
            },
            __webpack_module_cache__ = {};
        (__webpack_require__.m = __webpack_modules__),
            (deferred = []),
            (__webpack_require__.O = function (result, chunkIds, fn, priority) {
                if (!chunkIds) {
                    var notFulfilled = Infinity;
                    for (i = 0; i < deferred.length; i++) {
                        (chunkIds = deferred[i][0]), (fn = deferred[i][1]), (priority = deferred[i][2]);
                        for (var fulfilled = !0, j = 0; j < chunkIds.length; j++)
                            (!1 & priority || notFulfilled >= priority) &&
                            Object.keys(__webpack_require__.O).every(function (key) {
                                return __webpack_require__.O[key](chunkIds[j]);
                            })
                                ? chunkIds.splice(j--, 1)
                                : ((fulfilled = !1), priority < notFulfilled && (notFulfilled = priority));
                        if (fulfilled) {
                            deferred.splice(i--, 1);
                            var r = fn();
                            void 0 !== r && (result = r);
                        }
                    }
                    return result;
                }
                priority = priority || 0;
                for (var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--)
                    deferred[i] = deferred[i - 1];
                deferred[i] = [chunkIds, fn, priority];
            }),
            (__webpack_require__.n = function (module) {
                var getter =
                    module && module.__esModule
                        ? function () {
                              return module.default;
                          }
                        : function () {
                              return module;
                          };
                return __webpack_require__.d(getter, { a: getter }), getter;
            }),
            (__webpack_require__.d = function (exports, definition) {
                for (var key in definition)
                    __webpack_require__.o(definition, key) &&
                        !__webpack_require__.o(exports, key) &&
                        Object.defineProperty(exports, key, { enumerable: !0, get: definition[key] });
            }),
            (__webpack_require__.o = function (obj, prop) {
                return Object.prototype.hasOwnProperty.call(obj, prop);
            }),
            (__webpack_require__.r = function (exports) {
                'undefined' != typeof Symbol &&
                    Symbol.toStringTag &&
                    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' }),
                    Object.defineProperty(exports, '__esModule', { value: !0 });
            }),
            (function () {
                var installedChunks = { 179: 0 };
                __webpack_require__.O.j = function (chunkId) {
                    return 0 === installedChunks[chunkId];
                };
                var webpackJsonpCallback = function (parentChunkLoadingFunction, data) {
                        var moduleId,
                            chunkId,
                            chunkIds = data[0],
                            moreModules = data[1],
                            runtime = data[2],
                            i = 0;
                        if (
                            chunkIds.some(function (id) {
                                return 0 !== installedChunks[id];
                            })
                        ) {
                            for (moduleId in moreModules)
                                __webpack_require__.o(moreModules, moduleId) &&
                                    (__webpack_require__.m[moduleId] = moreModules[moduleId]);
                            if (runtime) var result = runtime(__webpack_require__);
                        }
                        for (parentChunkLoadingFunction && parentChunkLoadingFunction(data); i < chunkIds.length; i++)
                            (chunkId = chunkIds[i]),
                                __webpack_require__.o(installedChunks, chunkId) &&
                                    installedChunks[chunkId] &&
                                    installedChunks[chunkId][0](),
                                (installedChunks[chunkId] = 0);
                        return __webpack_require__.O(result);
                    },
                    chunkLoadingGlobal = (self.webpackChunkSettings = self.webpackChunkSettings || []);
                chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0)),
                    (chunkLoadingGlobal.push = webpackJsonpCallback.bind(
                        null,
                        chunkLoadingGlobal.push.bind(chunkLoadingGlobal),
                    ));
            })();
        var __webpack_exports__ = __webpack_require__.O(void 0, [596], function () {
            return __webpack_require__(780);
        });
        return (__webpack_exports__ = __webpack_require__.O(__webpack_exports__)), __webpack_exports__;
    })();
});

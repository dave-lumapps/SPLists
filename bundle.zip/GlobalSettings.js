define('GlobalSettings', ['react', '@lumx/react', 'lumapps-sdk-js'], function (
    __WEBPACK_EXTERNAL_MODULE__650__,
    __WEBPACK_EXTERNAL_MODULE__432__,
    __WEBPACK_EXTERNAL_MODULE__224__,
) {
    return (function () {
        'use strict';
        function __webpack_require__(moduleId) {
            var cachedModule = __webpack_module_cache__[moduleId];
            if (void 0 !== cachedModule) return cachedModule.exports;
            var module = (__webpack_module_cache__[moduleId] = { exports: {} });
            return __webpack_modules__[moduleId](module, module.exports, __webpack_require__), module.exports;
        }
        var __webpack_modules__ = {
                432: function (module) {
                    module.exports = __WEBPACK_EXTERNAL_MODULE__432__;
                },
                224: function (module) {
                    module.exports = __WEBPACK_EXTERNAL_MODULE__224__;
                },
                650: function (module) {
                    module.exports = __WEBPACK_EXTERNAL_MODULE__650__;
                },
            },
            __webpack_module_cache__ = {};
        (__webpack_require__.n = function (module) {
            var getter =
                module && module.__esModule
                    ? function () {
                          return module.default;
                      }
                    : function () {
                          return module;
                      };
            return __webpack_require__.d(getter, { a: getter }), getter;
        }),
            (__webpack_require__.d = function (exports, definition) {
                for (var key in definition)
                    __webpack_require__.o(definition, key) &&
                        !__webpack_require__.o(exports, key) &&
                        Object.defineProperty(exports, key, { enumerable: !0, get: definition[key] });
            }),
            (__webpack_require__.o = function (obj, prop) {
                return Object.prototype.hasOwnProperty.call(obj, prop);
            }),
            (__webpack_require__.r = function (exports) {
                'undefined' != typeof Symbol &&
                    Symbol.toStringTag &&
                    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' }),
                    Object.defineProperty(exports, '__esModule', { value: !0 });
            });
        var __webpack_exports__ = {};
        return (
            (function () {
                function _nonIterableRest() {
                    throw new TypeError(
                        'Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.',
                    );
                }
                function _unsupportedIterableToArray(o, minLen) {
                    if (o) {
                        if ('string' == typeof o) return _arrayLikeToArray(o, minLen);
                        var n = Object.prototype.toString.call(o).slice(8, -1);
                        return (
                            'Object' === n && o.constructor && (n = o.constructor.name),
                            'Map' === n || 'Set' === n
                                ? Array.from(o)
                                : 'Arguments' === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                                ? _arrayLikeToArray(o, minLen)
                                : void 0
                        );
                    }
                }
                function _arrayLikeToArray(arr, len) {
                    (null == len || len > arr.length) && (len = arr.length);
                    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
                    return arr2;
                }
                function _iterableToArrayLimit(arr, i) {
                    var _i =
                        null == arr
                            ? null
                            : ('undefined' != typeof Symbol && arr[Symbol.iterator]) || arr['@@iterator'];
                    if (null != _i) {
                        var _s,
                            _e,
                            _arr = [],
                            _n = !0,
                            _d = !1;
                        try {
                            for (
                                _i = _i.call(arr);
                                !(_n = (_s = _i.next()).done) && (_arr.push(_s.value), !i || _arr.length !== i);
                                _n = !0
                            );
                        } catch (err) {
                            (_d = !0), (_e = err);
                        } finally {
                            try {
                                _n || null == _i.return || _i.return();
                            } finally {
                                if (_d) throw _e;
                            }
                        }
                        return _arr;
                    }
                }
                function _arrayWithHoles(arr) {
                    if (Array.isArray(arr)) return arr;
                }
                __webpack_require__.r(__webpack_exports__),
                    __webpack_require__.d(__webpack_exports__, {
                        WidgetGlobalSettings: function () {
                            return WidgetGlobalSettings;
                        },
                    });
                var external_react_ = __webpack_require__(650),
                    external_react_default = __webpack_require__.n(external_react_),
                    react_ = __webpack_require__(432),
                    external_lumapps_sdk_js_ = __webpack_require__(224),
                    defaultGlobalSettings_baseUrl = 'https://picsum.photos/',
                    WidgetGlobalSettings = function (_ref) {
                        var arr,
                            i,
                            _ref$properties = _ref.properties,
                            properties = void 0 === _ref$properties ? {} : _ref$properties,
                            exportProp = _ref.exportProp,
                            _useState = (0, external_react_.useState)(
                                properties.baseUrl || defaultGlobalSettings_baseUrl,
                            ),
                            _useState2 =
                                ((arr = _useState),
                                (i = 2),
                                _arrayWithHoles(arr) ||
                                    _iterableToArrayLimit(arr, i) ||
                                    _unsupportedIterableToArray(arr, i) ||
                                    _nonIterableRest()),
                            baseUrl = _useState2[0],
                            setBaseUrl = _useState2[1],
                            debouncedBaseUrl = (0, external_lumapps_sdk_js_.useDebounce)(baseUrl, 800);
                        return (
                            (0, external_lumapps_sdk_js_.useExportProps)(
                                debouncedBaseUrl,
                                'baseUrl',
                                properties,
                                exportProp,
                            ),
                            external_react_default().createElement(
                                'div',
                                null,
                                external_react_default().createElement(react_.TextField, {
                                    className: 'mt0 ml',
                                    label: 'URL',
                                    value: baseUrl,
                                    onChange: setBaseUrl,
                                }),
                            )
                        );
                    };
            })(),
            __webpack_exports__
        );
    })();
});
